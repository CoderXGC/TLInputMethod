package com.hit.wi.define;

/**
 * Created by xujc on 9/2/15.
 */
public class FilePath {
    public static String ROOT_DIR = "/data/data/com.hit.wi.t9/dict/";
}
