package com.hit.wi.t9.datastruct;

/**
 * Created by Administrator on 2015/6/4.
 */
public class SkinInfoDataStruct {
    public int textcolor_functionKeys;
    public int textcolor_candidate_qk;
    public int textcolor_quickSymbol;
    public int textcolor_delete;
    public int textcolor_t9keys;
    public int textcolor_26keys;
    public int textcolor_zero;
    public int textcolor_space;
    public int textcolor_enter;
    public int textcolor_candidate_t9;
    public int textcolor_preEdit;
    public int textcolor_shift;

    public int backcolor_functionKeys;
    public int backcolor_candidate_qk;
    public int backcolor_quickSymbol;
    public int backcolor_delete;
    public int backcolor_t9keys;
    public int backcolor_26keys;
    public int backcolor_zero;
    public int backcolor_space;
    public int backcolor_enter;
    public int backcolor_candidate_t9;
    public int backcolor_preEdit;
    public int backcolor_shift;
    public int backcolor_smile;
    public int backcolor_prefix;
    public int backcolor_editText;//i dont know what it is

    public int backcolor_touchdown;
    public int shadow;

    public int skinId;
    public String skinName;
}
