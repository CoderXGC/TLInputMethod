package com.hit.wi.t9.view;

import android.content.Context;
import android.view.SurfaceView;

public class T9InputView extends SurfaceView {

    public T9InputView(Context context) {
        super(context);
    }
}
