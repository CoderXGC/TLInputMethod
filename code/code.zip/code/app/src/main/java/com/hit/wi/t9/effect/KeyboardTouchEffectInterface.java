package com.hit.wi.t9.effect;

/**
 * Created by Administrator on 2015/7/5.
 */
public interface KeyboardTouchEffectInterface {
    void onPressEffect();

    void onSlideEffect();
}
