package com.hit.wi.t9.Interfaces;

/**
 * Created by Administrator on 2015/5/23.
 */
public interface SoftKeyboardInterface {

    void switchKeyboardTo(int keyboard, boolean showAnim);

}
