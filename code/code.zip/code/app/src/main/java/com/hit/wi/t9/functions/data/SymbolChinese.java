package com.hit.wi.t9.functions.data;

/**
 * Created by xujc on 9/5/15.
 */
public class SymbolChinese {
    public static final String[] DATA = {
            "，",
            "。",
            "？",
            "……",
            "！",
            "~",
            "@",
            "#",
            "——",
            "·",
            "：",
            "、",
            "；",
            "“”",
            "‘’",
            "（）",
            "［］",
            "【】",
            "〖〗",
            "《》",
            "｛｝",
            "「」",
            "『』",
            "〈〉",
            "＋",
            "－",
            "＊",
            "／",
            "\\",
            "＝",
            "￥",
    };
}