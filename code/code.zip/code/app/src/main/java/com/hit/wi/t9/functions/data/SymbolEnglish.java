package com.hit.wi.function.data;

/**
 * Created by xujc on 9/5/15.
 */
public class SymbolEnglish {
    public static final String[] DATA = {
            ",",
            ".",
            "'",
            "?",
            "!",
            "~",
            "@",
            "()",
            "[]",
            "{}",
            ":",
            ";",
            "+",
            "-",
            "*",
            "/",
            "\\",
            "=",
            "_",
            "#",
            "<",
            ">",
            "\"",
            "|",
            "`",
            "$",
            "%",
            "^",
            "&",
            "￡",
    };
}