package com.hit.wi.t9.functions.data;

import com.hit.wi.t9.functions.data.emojicon.*;

/**
 * Created by xujc on 9/5/15.
 */

public class SymbolEmoji {
    public static final String[] FACE_DATA = PeopleEmoji.DATA;
    public static final String[] NATURE = NatureEmoji.DATA;
    public static final String[] OBJECT = ObjectsEmoji.DATA;
    public static final String[] PLACE = PlacesEmoji.DATA;
    public static final String[] SYMBOLS = SymbolsEmoji.DATA;
}
