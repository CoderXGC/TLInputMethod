package com.hit.wi.t9.values;

/**
 * Created by Administrator on 2015/6/4.
 */
public class QuickSymbolsDataStruct {
    public String[] chineseSymbols;
    public String[] englishSymbols;
    public String[] numberSymbols;
}
