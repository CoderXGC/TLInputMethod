package com.hit.wi.t9.Interfaces;

/**
 * Created by Administrator on 2015/7/28.
 */
public interface ViewGroupInterface {

    void updateSkin();
}
